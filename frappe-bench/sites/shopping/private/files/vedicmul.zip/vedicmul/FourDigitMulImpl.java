//F:\tejavaprog\javarmi\

import java.rmi.*;
import java.rmi.server.*;
public class FourDigitMulImpl extends UnicastRemoteObject implements FourDigitMulIntf 
{
	public FourDigitMulImpl() throws RemoteException 
	{
	}
	public int fourdigitmul(int d1, int d2,int d3, int d4) throws RemoteException 
	{
		return ((d1 * d4)+(d2 * d3));  // 27 * 49  here d1= 7 d2=2 d3=9 d4=4
		//multiplication is  7*4 + 2*9 = 28+18 = 46
		
	}
	
}