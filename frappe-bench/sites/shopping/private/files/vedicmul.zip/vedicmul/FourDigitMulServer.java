import java.net.*;
import java.rmi.*;
public class FourDigitMulServer 
{
public static void main(String args[]) 
{
	try 
	{
		FourDigitMulImpl fourdigit = new FourDigitMulImpl();
		Naming.rebind("FourDigitMulServer", fourdigit);
		System.out.println("********** Four Digit Multiplication and Sum Server is running ***********");
	}
	catch(Exception e) 
	{
		System.out.println("Exception: " + e);
	}
}
}