import java.rmi.*;
public interface TwoDigitMulIntf extends Remote 
{
	int twodigitmul(int d1, int d2) throws RemoteException;

}