//F:\tejavaprog\javarmi\

import java.rmi.*;
import java.rmi.server.*;
public class TwoDigitMulImpl extends UnicastRemoteObject implements TwoDigitMulIntf 
{
	public TwoDigitMulImpl() throws RemoteException 
	{
	}
	public int twodigitmul(int d1, int d2) throws RemoteException 
	{
		return d1 * d2;
	}
	
}