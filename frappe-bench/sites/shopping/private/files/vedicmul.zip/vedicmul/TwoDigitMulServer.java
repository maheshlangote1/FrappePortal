import java.net.*;
import java.rmi.*;
public class TwoDigitMulServer 
{
public static void main(String args[]) 
{
	try 
	{
		TwoDigitMulImpl twodigit = new TwoDigitMulImpl();
		Naming.rebind("TwoDigitMulServer", twodigit);
		System.out.println("********** Two Digit Multiplication Server is running ***********");
	}
	catch(Exception e) 
	{
		System.out.println("Exception: " + e);
	}
}
}