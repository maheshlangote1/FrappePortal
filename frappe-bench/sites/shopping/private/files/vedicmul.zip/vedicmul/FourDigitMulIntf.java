import java.rmi.*;
public interface FourDigitMulIntf extends Remote 
{
	int fourdigitmul(int d1, int d2,int d3, int d4) throws RemoteException;

}