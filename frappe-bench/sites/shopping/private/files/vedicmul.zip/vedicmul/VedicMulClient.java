import java.rmi.*;
public class VedicMulClient {
	public static void main(String args[]) 
	{
		int result=0;
		
			try {
				String twodigitmulServerURL = "rmi://" + "127.0.0.1" + "/TwoDigitMulServer";
				String fourdigitmulServerURL = "rmi://" + "127.0.0.1" + "/FourDigitMulServer";
				
				TwoDigitMulIntf twodigitmulServerIntf =	(TwoDigitMulIntf)Naming.lookup(twodigitmulServerURL);
				FourDigitMulIntf fourdigitmulServerIntf = (FourDigitMulIntf)Naming.lookup(fourdigitmulServerURL);
				
				System.out.println("The first number is: " + args[0]);
				int n1 = Integer.valueOf(args[0]).intValue();
				
				int d1=n1%10;
				int d2=n1/10;
				
				System.out.println("The second number is: " + args[1]);
				int n2 = Integer.valueOf(args[1]).intValue();
				
				int d3=n2%10;
				int d4=n2/10;
				
				System.out.println("d1="+d1+" d2="+d2+" d3="+d3+" d4="+d4);
				
				//result of distriubted system
				//the result is r3r2r2 and carry c2c1
				
				int tempr1=twodigitmulServerIntf.twodigitmul(d1, d3);  //result may be two digit so seperate it
				System.out.println("The first mul is: " + tempr1);
				result= tempr1%10;
				int c1=tempr1/10;
				System.out.println("Last digit="+result+"  carry 1:"+c1);
				
				int tempr2=fourdigitmulServerIntf.fourdigitmul(d1,d2,d3,d4);
				System.out.println("The Second mul is: " + tempr2);
				int seclast=((c1+ tempr2) % 10 );
				result= result+ (10 * seclast);
				int c2=(c1+ tempr2) / 10;
				System.out.println("Second digit="+seclast+"  carry 2:"+c2);
				
				System.out.println("Partial result ="+result);
				
				int tempr3=twodigitmulServerIntf.twodigitmul(d2, d4);  //result may be two digit so seperate it
				System.out.println("The third mul is: " + tempr3);
				
				result=result + ((100 * ( c2 + tempr3)));
				
				System.out.println("Result is ="+result);
			}
			catch(Exception e) {
				System.out.println("Exception: " + e);
			}
		}
}